from django.shortcuts import render
from django.http import HttpResponse
from .models import Pizza
from django.core import serializers


# Create your views here.


def index(request):
    pizzas = Pizza.objects.all().order_by("prix")
    # pizza_name_and_price = [f"{pizza.nom}: {pizza.prix} €" for pizza in pizzas]
    # pizza_names_str = ", ".join(pizza_name_and_price)
    # return HttpResponse(f"Les pizzas : {pizza_names_str}")
    return render(request, "menu/index.html", {"pizzas": pizzas})


def api_get_pizza(request):
    pizzas = Pizza.objects.all()
    json = serializers.serialize("json", pizzas)
    return HttpResponse(json)
